package study;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class lession1 {
		
		public static WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://192.168.254.252:8080/browse/RW-53");
		driver.manage().window().maximize();
		driver.findElement(By.id("login-form-username")).sendKeys("kamleshk");
		driver.findElement(By.id("login-form-password")).sendKeys("Analec@789#");
		driver.findElement(By.id("login-form-submit")).click();

