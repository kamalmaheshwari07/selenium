package Demo;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class DependencyTest {
  
  @BeforeMethod
  public void beforeMethod() {
  }
  
  @Test(enabled=false)
  public void openBrowser() {
	  System.out.println("open broswer");
	  
  }
  
  @Test (dependsOnMethods= {"openBrowser"} )
  public void navigateToUrl() {
	  System.out.println("Navigate to URL");
	  
  }
  
  @Test (dependsOnMethods= {"navigateToUrl"})
  public void login() {
	  System.out.println("login to website");
	  
  }

  @AfterMethod
  public void afterMethod() {
  }

}
