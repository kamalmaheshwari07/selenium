package Demo;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import Utility.ExcelUtil1;

public class datadriven {
	public static WebDriver driver;
	public static void main(String[] args) {
	

		try {
			ExcelUtil1.readExcel("D:/kamal/work/TestNg/src/TestData", "TestData.xlsx", "Sheet1");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
//		 String Username=ExcelUtil1.readExcel.("Sheet1", "Username", 2);
//		System.out.println(Username);
		 
		
//		
//		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
//			
//			 driver = new ChromeDriver();
//			 driver.manage().window().maximize();
//
//			 driver.get("http://52.38.187.37/ResearchPortal/LatestResearch");
//			 
//			 
//			 WebDriverWait wait = new WebDriverWait(driver,10);
//				WebElement element3=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='loginLink']")));
//				element3.click();
//				// driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
//				
//				WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='ResearchModalLogin']/div/div/div/div[2]/input")));
//				 
//				driver.findElement(By.xpath("//*[@id='LoginID']")).sendKeys(sUsername);
//				driver.findElement(By.xpath("//*[@id='Password']")).sendKeys(sPassword);
//				driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[2]/button")).click();
	}

}
