package Demo;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Sample {
  @BeforeSuite //1
  public void beforeSuite() {
	  System.out.println("beforeSuite hi1");
  }
  @BeforeTest //2
  public void beforeTest() {
	  System.out.println(" beforeTest hi2");
  }
  @BeforeClass  //3
  public void beforeClass() {
	  System.out.println("beforeClass hi3");
  }
  @BeforeMethod  //4
  public void beforeMethod() {
	  System.out.println("beforeMethod hi4");
  }

  @Test
  public void sample() {
	  System.out.println("Test One hello");
  }
  @Test  //5
  public void sample1() {
	  System.out.println("Test two kamal");
  }


  @AfterMethod //6
  public void afterMethod() {
	  System.out.println("afterMethod Bye4");
  }
  @AfterClass //7
  public void afterClass() {
	  System.out.println("afterClass Bye3");
  }
  @AfterTest //8
  public void afterTest() {
	  System.out.println("afterTest Bye2");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("afterSuite Bye1");
  }

}
