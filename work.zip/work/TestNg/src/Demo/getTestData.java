package Demo;



public class getTestData {
 
  public static void getDatafromExcel() {
	  
	  
	  
  }
}
