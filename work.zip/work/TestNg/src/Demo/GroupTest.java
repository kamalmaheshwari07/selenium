package Demo;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class GroupTest {
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("before method");
  }
  
  @Test(groups={"car"})
  public void test1() {
	  System.out.println("Car1");
  }
  
  @Test(groups={"car"})
  public void test2() {
	  System.out.println("Car2");
  }
  
  @Test(groups={"Scootor"})
  public void test3() {
	  System.out.println("Scootor1");
  }
  
  @Test(groups={"Scootor"})
  public void test4() {
	  System.out.println("Scootor2");
  }
  
  @Test(groups={"car","Scootor"})
  public void test5() {
	  System.out.println("Car&Scootor");
  }
  
  @Test(groups={"car","Scootor"})
  public void test6() {
	  System.out.println("Car&Scootor");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("after method");
  }

}
