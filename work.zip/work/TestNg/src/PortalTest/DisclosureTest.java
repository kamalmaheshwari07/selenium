package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class DisclosureTest {
	public static WebDriver driver;

  @BeforeMethod
  @Parameters({"sUrl"})
  public void beforeMethod(String sUrl) {
	  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
		
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get(sUrl);
  }

  @Test(priority=1)
  @Parameters({"sUsername","sPassword"})
  public void Disclosure(String sUsername , String sPassword) {
	  WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement element3=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='loginLink']")));
		element3.click();
		WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='ResearchModalLogin']/div/div/div/div[2]/input")));
		 
		driver.findElement(By.xpath("//*[@id='LoginID']")).sendKeys(sUsername);
		driver.findElement(By.xpath("//*[@id='Password']")).sendKeys(sPassword);
		driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[2]/button")).click();
				
		WebDriverWait wait1 = new WebDriverWait(driver,50);
		WebElement element1=wait1.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-sign-out")));

		String msg =driver.findElement(By.xpath("//*[@id='Latest_Report']")).getText();
		Assert.assertEquals(msg, "LATEST", "home page is not loaded");
		driver.findElement(By.id("Disclosures_Report")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
  }
  
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
