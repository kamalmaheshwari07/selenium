package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class UpcomingEventTest {
	public static WebDriver driver;

	@BeforeMethod
	@Parameters({"sUrl"})
	public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();

			 driver.get(sUrl);
	}


  @Test(priority=1)
  public void UpcomingEventTest() {
	  
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.findElement(By.id("TopPicksLink")).click();
	  String msg=driver.findElement(By.cssSelector("div.media-body > span")).getText();
	  Assert.assertEquals(msg, "No Upcoming Events to display","Passed");
	  	   
  }
  
 
  @AfterMethod
  public void afterMethod() {
	driver.quit();
  }

}
