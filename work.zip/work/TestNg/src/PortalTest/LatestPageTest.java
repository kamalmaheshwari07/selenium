package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class LatestPageTest {
	public static WebDriver driver;

	@BeforeMethod
	  @Parameters({"sUrl"})
	  public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();

			 driver.get(sUrl);
	  }


  @Test(priority=1)
  @Parameters({"sValue","sValue1"})
  public void latestPageTest1(String sValue, String sValue1) {
	  WebDriverWait wait=new WebDriverWait(driver,10);
	  WebElement element=wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='SectorSrch-term']"))));
	  element.sendKeys("sValue");
	  WebElement msg=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='div_noresearch']/div/span")));
	  String val=msg.getText();
	  Assert.assertEquals(val, "No Research Reports To display.","displayed result is wrong");
	  
  }
  
  @Test(priority=2)
  @Parameters({"sValue","sValue1"})
  public void latestPageTest2(String sValue, String sValue1) {
	  WebDriverWait wait=new WebDriverWait(driver,10);
	  WebElement element=wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='SectorSrch-term']"))));
	  element.sendKeys(sValue1);
	  WebElement msg=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='list_research_detail']/li[1]/div/div[2]/div[1]/span")));
	  String val=msg.getText();
	  boolean b=val.contains(sValue1);
	  Assert.assertTrue(b);
	  driver.findElement(By.xpath("//*[@id='list_research_detail']/li[1]/div/div[2]/div[1]/span/a")).click();  
	  WebElement element1=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='ResearchModalLogin']/div/div/div/div[2]/input")));
	  boolean ab=element1.isDisplayed();
	  Assert.assertTrue(ab);
			  
  }
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
