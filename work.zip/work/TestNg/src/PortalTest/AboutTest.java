package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class AboutTest {
	public static WebDriver driver;

	@BeforeMethod
	  @Parameters({"sUrl"})
	  public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 driver.get(sUrl);
	  }


  @Test(priority=1)
  public void About() {
	  WebDriverWait wait=new WebDriverWait(driver,10);
	  WebElement element=wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='liABOUT']/a"))));
	  element.click();
	  String val=driver.findElement(By.id("Aboutus")).getText();
	  Assert.assertEquals(val, "ABOUT US", "value is not available");
//	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  String val1=driver.findElement(By.id("contactus")).getText();
	  Assert.assertEquals(val1, "CONTACT US", "value is not available");
		  	   
  }
  
 
  @AfterMethod
  public void afterMethod() {
	driver.quit();
  }

}
