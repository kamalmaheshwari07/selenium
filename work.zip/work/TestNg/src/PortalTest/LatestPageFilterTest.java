package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class LatestPageFilterTest {
	public static WebDriver driver;

	@BeforeMethod
	  @Parameters({"sUrl"})
	  public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();

			 driver.get(sUrl);
	  }


  @Test(priority=1)
  @Parameters({"sValue2","sValue1"})
  public void latestPageTest1(String sValue2, String sValue1) {
	  WebDriverWait wait=new WebDriverWait(driver,10);
	  WebElement element=wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector("button.btn.btn-default"))));
	  element.click();
	  
	  WebElement element1=wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("ddl_reports"))));
	  element1.click();
	  Select type=new Select(driver.findElement(By.id("ddl_reports")));
	  type.selectByVisibleText(sValue2);
	  
		  
	 
	  
  }
  
 
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
