package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class ForgotPasswordTest {
	public static WebDriver driver;

	@BeforeMethod
	  @Parameters({"sUrl"})
	  public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();

			 driver.get(sUrl);
	  }


  @Test
  @Parameters({"sEmail"})
  public void forgotPasswordTest(String sEmail) {
	  driver.findElement(By.xpath("//*[@id='loginLink']")).click();
		// driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver,10);
		//*[@id="ResearchModalLogin"]/div/div/div/div[2]/span[3]/a
		WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[2]/span[3]/a")));
		element.click();
		String msg=driver.findElement(By.xpath("//*[@id='loginContainer']/div/div/div[2]/div/p")).getText();
		Assert.assertEquals(msg, "Please enter your email to receive a link to reset your password.","Page is not correct");
		driver.findElement(By.xpath("//*[@id='UserNameTextBox']")).sendKeys(sEmail);
		WebElement element1=wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".btn")));
		element1.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String msg1=driver.findElement(By.cssSelector(".col-lg-6")).getText();
		Assert.assertEquals(msg1, "Thank you.","email not sent Successfully ");
	  
	  
  }
  
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
