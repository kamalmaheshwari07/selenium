package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class ForgotPasswordLinkTest {
	public static WebDriver driver;

	@BeforeMethod
	  @Parameters({"sUrl"})
	  public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();

			 driver.get(sUrl);
	  }


  @Test
  @Parameters({"sNewPassword","sPasswordLink"})
  public void forgotPasswordLinkTest(String sNewPassword , String sPasswordLink) {
	  	driver.get(sPasswordLink);
	  	WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='UserPasswordTextBox']")));
		element.sendKeys(sNewPassword);
		driver.findElement(By.xpath("//*[@id='ConfirmPasswordTextBox']")).sendKeys(sNewPassword);
		driver.findElement(By.xpath("//*[@id='loginContainer']/div/div/div[2]/div/form/div[3]/input")).click();
		
		String msg=driver.findElement(By.xpath("//*[@id='VaildationSummarydiv']/span[2]/span")).getText();
		System.out.println(msg);
		Assert.assertEquals(msg, "Password successfully changed! Redirecting to the login page in 5 seconds... or click here.","Password Change Successfully");
		
	  
	  
  }
  
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
