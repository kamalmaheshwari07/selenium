package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class AuthorPageTest {
	public static WebDriver driver;

  @BeforeMethod
  @Parameters({"sUrl"})
  public void beforeMethod(String sUrl) {
	  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
		
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();

		 driver.get(sUrl);
  }

  @Test
  @Parameters({"sUsername","sPassword"})
  public void AuthorPage(String sUsername , String sPassword) {
	  WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement element3=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='loginLink']")));
		element3.click();
		WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='ResearchModalLogin']/div/div/div/div[2]/input")));
		 
		driver.findElement(By.xpath("//*[@id='LoginID']")).sendKeys(sUsername);
		driver.findElement(By.xpath("//*[@id='Password']")).sendKeys(sPassword);
		driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[2]/button")).click();
				
		WebDriverWait wait1 = new WebDriverWait(driver,50);
		WebElement element1=wait1.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-sign-out")));

		String msg =driver.findElement(By.xpath("//*[@id='Latest_Report']")).getText();
		Assert.assertEquals(msg, "LATEST", "home page is not loaded");
		driver.findElement(By.id("Author_Report")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		List<WebElement> elems = driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/button"));
		
//		System.out.println(elems.size());
		for(int i=1;i<=elems.size();i++){
			
			String ab=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/button["+i+"]")).getText();
				if(ab.equals("Garry Sherriff")){
				driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/button["+i+"]")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				String nam=driver.findElement(By.xpath("//*[@id='list_research_detail_author']/div[1]/div[2]/div[1]")).getText();
				
				Assert.assertEquals(nam, "Garry Sherriff","wrong page is loaded");
				break;
			}
		}

  }
  
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}
