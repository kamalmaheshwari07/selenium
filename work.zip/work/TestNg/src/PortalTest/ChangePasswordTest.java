package PortalTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class ChangePasswordTest {
	
	public static WebDriver driver;
	
	@BeforeMethod
	  @Parameters({"sUrl"})
	  public void beforeMethod(String sUrl) {
		  System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
			
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 driver.get(sUrl);
	  }

  
  @Test
  @Parameters({"sUsername","sPassword","sNewPassword"})
  public void ChangePassword(String sUsername , String sPassword , String sNewPassword) {
	  WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement element3=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='loginLink']")));
		element3.click();
		// driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
		WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='ResearchModalLogin']/div/div/div/div[2]/input")));
		driver.findElement(By.xpath("//*[@id='LoginID']")).sendKeys(sUsername);
		driver.findElement(By.xpath("//*[@id='Password']")).sendKeys(sPassword);
		driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[2]/button")).click();
				
		WebDriverWait wait1 = new WebDriverWait(driver,50);
		WebElement element1=wait1.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".fa-sign-out")));
		
//		String msg =driver.findElement(By.xpath("//*[@id='Latest_Report']")).getText();
//		Assert.assertEquals(msg, "LATEST", "home page is not loaded");
		Boolean  a=driver.findElement(By.cssSelector(".fa-sign-out")).isDisplayed();
		Assert.assertTrue(a, "Signout button is not displayed");
		driver.findElement(By.cssSelector(".fa-sign-out")).click();
		driver.findElement(By.id("ChangePasswordLink")).click();
		driver.findElement(By.xpath("//*[@id='loginContainer']/div/div/h2")).getText().equals("Change Password");
		driver.findElement(By.id("OldPassword")).sendKeys(sPassword);
		driver.findElement(By.id("NewPassword")).sendKeys(sNewPassword);
		driver.findElement(By.id("ConfirmPassword")).sendKeys(sNewPassword);
		driver.findElement(By.cssSelector(".btn")).submit();
//		String msg1 =driver.findElement(By.xpath("//*[@id='Latest_Report']")).getText();
//		Assert.assertEquals(msg1, "LATEST", "home page is not loaded");
		Boolean b=driver.findElement(By.xpath("//*[@id='loginLink']")).isDisplayed();
		Assert.assertTrue(b, "Signout button is not displayed");
		
		
  }


  @AfterMethod
  public void afterMethod() {
	  	driver.quit();
  }

}
