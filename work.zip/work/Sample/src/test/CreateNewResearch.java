package test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class CreateNewResearch {
	
	public static WebDriver driver;
	public static String url;

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
		
				 driver = new ChromeDriver();
				 driver.manage().window().maximize();

				 driver.get("http://192.168.254.176/ResearchAuthor/Login/Login");
				 
				 
				 driver.findElement(By.id("UserName")).sendKeys("analecadmin");
				 driver.findElement(By.id("Password")).sendKeys("Password1");
				 driver.findElement(By.className("buttonsitemap")).click();
				 String val = driver.findElement(By.xpath("//*[@id='equalheight']/div/button[1]")).getText();
				 System.out.println(val);
				 driver.findElement(By.xpath("//*[@id='equalheight']/div/button[1]")).click();	
				 
				
				 //driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
				 
				 WebDriverWait wait = new WebDriverWait(driver,10);
				 WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id='ProcessTypeIGCombo']/span/input")));
				 Actions action = new Actions(driver);
				 WebElement but = driver.findElement(By.xpath("//span[@id='ProcessTypeIGCombo']/span/input"));
				 action.moveToElement(but).click().build().perform();
				 
				 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				 WebElement but1 = driver.findElement(By.xpath("//li[4]/div/div"));
				 action.moveToElement(but1).click().build().perform();
				
				//driver.findElement(By.xpath("//*[@id='SelectedReasonForCreationId']/span[1]/input")).sendKeys("Change in Numbers");
				 driver.findElement(By.xpath("//*[@id='AUTHOR']/span[1]/input")).sendKeys("Abhinav Kapur");
				 driver.findElement(By.xpath("//*[@id='AUTHOR']/span[1]/input")).sendKeys(Keys.ENTER);
				 
				 driver.findElement(By.xpath("//*[@id='INST']/span[1]/input")).sendKeys("Abaxis, Inc. (ABAX)");
				 driver.findElement(By.xpath("//*[@id='INST']/span[1]/input")).sendKeys(Keys.ENTER);
				 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				 driver.findElement(By.id("CreateUpdateButton")).click();
				 
				 driver.findElement(By.xpath("//*[@id='DocumentSubtitle']")).sendKeys("Test K ");
				
				 driver.switchTo().frame(0);
				 WebElement el= driver.switchTo().activeElement();
				 new Actions(driver).moveToElement(el).perform();
				 driver.findElement(By.xpath("/html/body")).sendKeys("please write somthing ");
				 driver.switchTo().parentFrame();
			
				 
				 driver.findElement(By.id("AnalystCertificationAcceptCheckBox")).click();
				 driver.findElement(By.id("ReportEditorResearchTagsDiv")).click();
				 driver.findElement(By.xpath("//*[@id='ResearchTagsKeywordControl']/ul/li[1]/span[2]")).click();
				 driver.findElement(By.id("KeywordTagsText")).sendKeys("testk");
				 driver.findElement(By.id("KeywordTagsText")).sendKeys(Keys.ENTER);
				// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				 driver.findElement(By.xpath("//*[@id='stageApprovalHeaderDiv']")).click();
				// driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				 System.out.println("k");
				 WebDriverWait wait1 = new WebDriverWait(driver,100);
				 System.out.println("k2");
//				 Thread.sleep(600000);
//				 driver.findElement(By.xpath("//div[@id='StageApprovalFastTrackDiv']/table/tbody/tr[3]/td/input")).click();
//				 System.out.println("k");//*[@id="StageApprovalFastTrackChk_2"]
//				 driver.findElement(By.xpath("//*[@id='StageApprovalFastTrackChk_3']")).click();
//				 System.out.println("k");
//				 driver.findElement(By.xpath("//*[@id='StageApprovalFastTrackChk_4']")).click();
//				 driver.findElement(By.id("FinalStageStageApprovalCheckBox")).click();
				 driver.findElement(By.xpath("//*[@id='AdditionalNotesDiv']")).click();
				 driver.findElement(By.id("AdditionalNotesTextarea")).sendKeys("test using selenium");
				 driver.findElement(By.id("DistributionDiv")).click();
				 driver.findElement(By.id("UserRoleBasedDistribution")).click();
				 driver.findElement(By.id("FileUploadDiv")).click();
				 			 
				 driver.findElement(By.id("AssosiateFilePath")).sendKeys("C:/Users/Administrator/Desktop/kamal/try.docx");
				 
				 
				 //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 WebDriverWait wait2 = new WebDriverWait(driver,60);
				 
				 System.out.println("k3");
				 WebElement btn= driver.findElement(By.name("AdditionalFileCheckBox"));
				 new Actions(driver).moveToElement(btn).perform();
//				 driver.findElement(By.name("AdditionalFileCheckBox")).click();
				 System.out.println("k4");
							 
				// driver.findElement(By.id("SubmitToWorkflowBtn")).click();
				 
				 
	}

}

