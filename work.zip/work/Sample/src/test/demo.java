package test;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class demo {
	
	public static WebDriver driver;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:/kamal/selenium/chromedriver_win32/chromedriver.exe");
		
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();

		 driver.get("https://52.35.26.240/ResearchPortal/LatestResearch");
		 driver.findElement(By.xpath("//*[@id='loginLink']")).click();
		// driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
		 WebDriverWait wait = new WebDriverWait(driver,10);
		 WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='ResearchModalLogin']/div/div/div/div[2]/input")));
		 
		driver.findElement(By.xpath("//*[@id='LoginID']")).sendKeys("analecadmin");
		driver.findElement(By.xpath("//*[@id='Password']")).sendKeys("Csupport@1");
		driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[2]/button")).click();
		WebDriverWait wait1 = new WebDriverWait(driver,50);
		 WebElement element1=wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='Category_Report']")));
		driver.findElement(By.xpath("//*[@id='Category_Report']")).click();
	   
				 
				 
//		 String mainWinHander = driver.getWindowHandle();
//		 System.out.println("kamal1");
//		// code for clicking button to open new window is ommited
//
//		//Now the window opened. So here reture the handle with size = 2
//		Set<String> handles = driver.getWindowHandles();
//System.out.println("kamal2");
//		for(String handle : handles)
//		{
//			System.out.println("kamal3");
//		    if(!mainWinHander.equals(handle))
//		    {
//		    	System.out.println("kamal4");
//		        // Here will block for ever. No exception and timeout!
//		        WebDriver popup = driver.switchTo().window(handle);
//		        System.out.println("kamal5");
//		
//     
//		    }}
//		 String Parent = driver.getWindowHandle();
//		 System.out.println(handle1);
//		 Set handles = driver.getWindowHandles();
//
//         for (String handle1 : driver.getWindowHandles()) {
// 
//          System.out.println(handle1);
// 
//          driver.switchTo().window(handle1);
//          driver.findElement(By.xpath("//*[@id='LoginID']")).sendKeys("kamal");
//          String a=driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[1]/h4")).getText();
// 		 System.out.println(a);
//         }
//	
//		 String a=driver.findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[1]/h4")).getText();
//		 System.out.println(a);
//		 driver.switchTo().frame("modal-dialog modal-sm").findElement(By.xpath("//*[@id='ResearchModalLogin']/div/div/div/div[1]/h4")).getText();		
//		 driver.findElement(By.id("UserName")).sendKeys("analecadmin");
//		 driver.findElement(By.id("Password")).sendKeys("Password1");
//		 driver.findElement(By.className("buttonsitemap")).click();

	}

}
